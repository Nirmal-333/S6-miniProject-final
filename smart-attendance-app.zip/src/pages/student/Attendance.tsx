import React, { useState } from 'react';
import { useStore } from '../../store';
import { format, parseISO, startOfWeek, addDays, isSameDay } from 'date-fns';
import { CheckCircle, XCircle, Calendar as CalendarIcon, Clock, User as UserIcon, MapPin, Plus, FileText, CalendarDays, ClipboardList, Check, X } from 'lucide-react';
import { clsx } from 'clsx';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

export default function StudentAttendance() {
  const { currentUser, sessions, users, attendances, addLeaveRequest, leaveRequests } = useStore();
  const [view, setView] = useState<'summary' | 'daily' | 'calendar' | 'absent' | 'leaves'>('summary');
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [leaveDate, setLeaveDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [leaveReason, setLeaveReason] = useState('');
  const [leaveType, setLeaveType] = useState('Leave');
  const [fromDate, setFromDate] = useState(format(new Date(), "yyyy-MM-dd'T'HH:mm"));
  const [toDate, setToDate] = useState(format(new Date(), "yyyy-MM-dd'T'HH:mm"));
  const [duration, setDuration] = useState('1 day');
  const [remarks, setRemarks] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date());

  if (!currentUser) return null;

  // Calculate stats
  const studentAttendances = attendances.filter(a => a.studentId === currentUser.id);
  const attendedSessionIds = studentAttendances.map(a => a.sessionId);
  
  // All completed sessions
  const completedSessions = sessions.filter(s => s.status === 'completed');
  const totalClasses = completedSessions.length;
  const present = studentAttendances.filter(a => a.status === 'present').length;
  const absent = totalClasses - present;
  const percentage = totalClasses > 0 ? Math.round((present / totalClasses) * 100) : 0;

  // Group by date
  const sessionsByDate = completedSessions.reduce((acc, session) => {
    if (!acc[session.date]) acc[session.date] = [];
    acc[session.date].push(session);
    return acc;
  }, {} as Record<string, typeof sessions>);

  // Absent sessions
  const absentSessions = completedSessions.filter(s => !attendedSessionIds.includes(s.id));

  // Subject-wise attendance
  const subjectStats = completedSessions.reduce((acc, session) => {
    if (!acc[session.activityName]) {
      acc[session.activityName] = { name: session.activityName, present: 0, absent: 0, total: 0 };
    }
    acc[session.activityName].total += 1;
    if (attendedSessionIds.includes(session.id)) {
      acc[session.activityName].present += 1;
    } else {
      acc[session.activityName].absent += 1;
    }
    return acc;
  }, {} as Record<string, { name: string, present: number, absent: number, total: number }>);

  const pieData = Object.values(subjectStats).map(stat => ({
    name: stat.name,
    value: stat.present,
    total: stat.total
  }));

  const myLeaves = leaveRequests.filter(l => l.userId === currentUser.id);

  const COLORS = ['#8b5cf6', '#ec4899', '#10b981', '#f59e0b', '#3b82f6', '#6366f1', '#14b8a6'];

  const handleLeaveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    
    await addLeaveRequest({
      userId: currentUser.id,
      leaveType,
      fromDate,
      toDate,
      duration,
      remarks,
      appliedBy: currentUser.id
    });
    
    setShowLeaveModal(false);
    setFromDate(format(new Date(), "yyyy-MM-dd'T'HH:mm"));
    setToDate(format(new Date(), "yyyy-MM-dd'T'HH:mm"));
    setDuration('1 day');
    setRemarks('');
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-violet-950">Attendance Record</h1>
          <p className="text-violet-600 mt-2">Track your presence and history</p>
        </div>
      </div>

      <div className="flex gap-4 mb-8 border-b border-violet-100 pb-4 overflow-x-auto">
        {[
          { id: 'summary', label: 'Summary', icon: FileText },
          { id: 'daily', label: 'Daily View', icon: Clock },
          { id: 'calendar', label: 'Calendar', icon: CalendarDays },
          { id: 'absent', label: 'Missed Classes', icon: XCircle },
          { id: 'leaves', label: 'My Leaves', icon: ClipboardList }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setView(tab.id as any)}
            className={clsx(
              "flex items-center gap-2 px-6 py-2.5 rounded-full font-medium transition-all whitespace-nowrap",
              view === tab.id 
                ? "bg-violet-600 text-white shadow-md shadow-violet-200" 
                : "bg-white text-gray-600 hover:bg-violet-50"
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {view === 'summary' && (
          <motion.div key="summary" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-violet-100 shadow-sm flex flex-col items-center justify-center">
            <div className="w-24 h-24 rounded-full border-8 border-violet-100 flex items-center justify-center relative mb-4">
              <svg className="absolute inset-0 w-full h-full -rotate-90">
                <circle cx="48" cy="48" r="40" fill="none" stroke="currentColor" strokeWidth="8" className="text-violet-100" />
                <circle 
                  cx="48" cy="48" r="40" fill="none" stroke="currentColor" strokeWidth="8" 
                  className="text-violet-600" 
                  strokeDasharray={`${(percentage / 100) * 251.2} 251.2`} 
                />
              </svg>
              <span className="text-2xl font-bold text-violet-950">{percentage}%</span>
            </div>
            <h3 className="text-gray-500 font-medium">Overall Attendance</h3>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-violet-100 shadow-sm flex flex-col justify-center">
            <div className="flex items-center gap-4 mb-2">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl"><CalendarIcon size={24} /></div>
              <div>
                <p className="text-3xl font-bold text-gray-900">{totalClasses}</p>
                <p className="text-sm text-gray-500 font-medium">Total Classes</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-violet-100 shadow-sm flex flex-col justify-center">
            <div className="flex items-center gap-4 mb-2">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl"><CheckCircle size={24} /></div>
              <div>
                <p className="text-3xl font-bold text-gray-900">{present}</p>
                <p className="text-sm text-gray-500 font-medium">Present</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-violet-100 shadow-sm flex flex-col justify-center">
            <div className="flex items-center gap-4 mb-2">
              <div className="p-3 bg-red-50 text-red-600 rounded-xl"><XCircle size={24} /></div>
              <div>
                <p className="text-3xl font-bold text-gray-900">{absent}</p>
                <p className="text-sm text-gray-500 font-medium">Absent</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-2xl border border-violet-100 shadow-sm">
            <h3 className="text-lg font-bold text-violet-950 mb-6">Subject-wise Attendance</h3>
            <div className="h-64">
              {pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number, name: string, props: any) => [`${value} / ${props.payload.total} Classes`, name]}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-gray-400">No attendance data yet</div>
              )}
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-2xl border border-violet-100 shadow-sm">
            <h3 className="text-lg font-bold text-violet-950 mb-6">Recent Activity</h3>
            <div className="space-y-4">
              {studentAttendances.sort((a,b) => b.timestamp - a.timestamp).slice(0, 5).map(att => {
                const session = sessions.find(s => s.id === att.sessionId);
                return (
                  <div key={att.id} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 border border-gray-100">
                    <div>
                      <p className="font-bold text-gray-900">{session?.activityName}</p>
                      <p className="text-xs text-gray-500">{format(att.timestamp, 'MMM dd, yyyy • HH:mm')}</p>
                    </div>
                    <span className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded-md text-xs font-bold">Present</span>
                  </div>
                );
              })}
              {studentAttendances.length === 0 && (
                <div className="text-center py-8 text-gray-400">No recent activity</div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
      )}

      {view === 'daily' && (
        <motion.div key="daily" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
          {Object.entries(sessionsByDate).sort((a,b) => b[0].localeCompare(a[0])).map(([date, daySessions]) => (
            <div key={date} className="bg-white rounded-2xl border border-violet-100 shadow-sm overflow-hidden">
              <div className="bg-violet-50 px-6 py-4 border-b border-violet-100">
                <h3 className="font-bold text-violet-950 flex items-center gap-2">
                  <CalendarIcon size={18} />
                  {format(parseISO(date), 'EEEE, MMMM do, yyyy')}
                </h3>
              </div>
              <div className="divide-y divide-gray-100">
                {daySessions.sort((a,b) => a.hour - b.hour).map(session => {
                  const faculty = users.find(u => u.id === session.facultyId);
                  const isAttended = attendedSessionIds.includes(session.id);
                  
                  return (
                    <div key={session.id} className="p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-violet-100 text-violet-800 flex flex-col items-center justify-center shrink-0">
                          <span className="text-xs font-medium opacity-70">Hr</span>
                          <span className="font-bold text-lg leading-none">{session.hour}</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-900">{session.activityName}</h4>
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-sm text-gray-500">
                            <span className="flex items-center gap-1"><UserIcon size={14} /> {faculty?.name}</span>
                            <span className="flex items-center gap-1"><MapPin size={14} /> {session.venue}</span>
                            <span className="flex items-center gap-1"><Clock size={14} /> {session.startTime} - {session.endTime}</span>
                          </div>
                        </div>
                      </div>
                      <div className="shrink-0 flex sm:flex-col items-center sm:items-end gap-2">
                        {isAttended ? (
                          <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-sm font-semibold flex items-center gap-1">
                            <CheckCircle size={16} /> Present
                          </span>
                        ) : (
                          <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-semibold flex items-center gap-1">
                            <XCircle size={16} /> Absent
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </motion.div>
      )}

      {view === 'calendar' && (
        <motion.div key="calendar" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
          <div className="bg-white rounded-2xl border border-violet-100 shadow-sm overflow-hidden p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-violet-950 text-xl">My Calendar</h3>
              <input 
                type="date" 
                value={format(selectedDate, 'yyyy-MM-dd')}
                onChange={(e) => setSelectedDate(parseISO(e.target.value))}
                className="p-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-600 outline-none"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
              {Array.from({ length: 7 }).map((_, i) => {
                const date = addDays(startOfWeek(selectedDate, { weekStartsOn: 1 }), i);
                const isSelected = isSameDay(date, selectedDate);
                const daySessions = completedSessions.filter(s => s.date === format(date, 'yyyy-MM-dd'));
                const presentCount = daySessions.filter(s => attendedSessionIds.includes(s.id)).length;
                
                return (
                  <div 
                    key={i}
                    onClick={() => setSelectedDate(date)}
                    className={clsx(
                      "p-4 rounded-xl border cursor-pointer transition-all",
                      isSelected ? "border-violet-600 bg-violet-50 shadow-sm" : "border-gray-100 hover:border-violet-300"
                    )}
                  >
                    <div className="text-sm font-medium text-gray-500 mb-1">{format(date, 'EEE')}</div>
                    <div className={clsx("text-2xl font-bold", isSelected ? "text-violet-900" : "text-gray-900")}>
                      {format(date, 'd')}
                    </div>
                    {daySessions.length > 0 && (
                      <div className="mt-2 text-xs font-medium text-violet-600 bg-violet-100 px-2 py-1 rounded-md inline-block">
                        {presentCount}/{daySessions.length} Attended
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="mt-8">
              <h4 className="font-bold text-gray-900 mb-4">Classes on {format(selectedDate, 'MMMM d, yyyy')}</h4>
              <div className="space-y-3">
                {completedSessions.filter(s => s.date === format(selectedDate, 'yyyy-MM-dd')).sort((a,b) => a.hour - b.hour).length === 0 ? (
                  <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                    No classes scheduled for this date.
                  </div>
                ) : (
                  completedSessions.filter(s => s.date === format(selectedDate, 'yyyy-MM-dd')).sort((a,b) => a.hour - b.hour).map(session => {
                    const fac = users.find(u => u.id === session.facultyId);
                    const isAttended = attendedSessionIds.includes(session.id);
                    return (
                      <div key={session.id} className="flex items-center gap-4 p-4 rounded-xl border border-gray-100 bg-gray-50 hover:bg-white hover:shadow-sm transition-all">
                        <div className="w-12 h-12 bg-violet-100 text-violet-700 rounded-xl flex items-center justify-center font-bold text-lg shrink-0">
                          H{session.hour}
                        </div>
                        <div className="flex-1">
                          <h5 className="font-bold text-gray-900">{session.activityName}</h5>
                          <p className="text-sm text-gray-500">{session.startTime} - {session.endTime} • {session.venue}</p>
                        </div>
                        <div className="text-right flex flex-col items-end gap-1">
                          <div className="text-sm font-medium text-gray-900">{fac?.name}</div>
                          {isAttended ? (
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-md text-xs font-bold">Present</span>
                          ) : (
                            <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-md text-xs font-bold">Absent</span>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {view === 'absent' && (
        <motion.div key="absent" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="bg-white rounded-2xl border border-red-100 shadow-sm overflow-hidden">
          <div className="bg-red-50 px-6 py-4 border-b border-red-100">
            <h3 className="font-bold text-red-900 flex items-center gap-2">
              <XCircle size={18} />
              Missed Sessions ({absentSessions.length})
            </h3>
          </div>
          {absentSessions.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              <CheckCircle size={48} className="mx-auto text-emerald-400 mb-4" />
              <p className="text-lg font-medium">Great job!</p>
              <p>You haven't missed any sessions yet.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {absentSessions.sort((a,b) => b.date.localeCompare(a.date)).map(session => {
                const faculty = users.find(u => u.id === session.facultyId);
                return (
                  <div key={session.id} className="p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-gray-50">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-bold text-red-600">{format(parseISO(session.date), 'MMM do')}</span>
                        <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                        <span className="text-sm font-medium text-gray-600">Hour {session.hour}</span>
                      </div>
                      <h4 className="font-bold text-gray-900 text-lg">{session.activityName}</h4>
                      <p className="text-sm text-gray-500 mt-1 flex items-center gap-2">
                        <UserIcon size={14} /> {faculty?.name}
                      </p>
                    </div>
                    <div className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-lg self-start sm:self-auto">
                      {session.department}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </motion.div>
      )}

      {view === 'leaves' && (
        <motion.div key="leaves" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
          <div className="bg-white rounded-2xl border border-violet-100 shadow-sm overflow-hidden p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-violet-950 text-xl">My Leave Requests</h3>
              <button
                onClick={() => setShowLeaveModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-violet-100 text-violet-700 rounded-lg font-medium hover:bg-violet-200 transition-colors"
              >
                <Plus size={16} />
                New Request
              </button>
            </div>
            <div className="space-y-4">
              {myLeaves.length === 0 ? (
                <div className="text-center py-12 text-gray-500 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                  You haven't submitted any leave requests yet.
                </div>
              ) : (
                myLeaves.sort((a, b) => b.timestamp - a.timestamp).map(request => (
                  <div key={request.id} className="p-5 rounded-xl border border-gray-100 bg-gray-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <span className="px-2 py-1 bg-violet-100 text-violet-700 text-xs font-bold rounded-full">
                          {request.leaveType}
                        </span>
                        <h4 className="font-bold text-gray-900">
                          {format(new Date(request.fromDate), 'MMM dd, yyyy')} - {format(new Date(request.toDate), 'MMM dd, yyyy')}
                        </h4>
                        <span className={clsx(
                          "text-xs font-bold px-2 py-1 rounded-md capitalize flex items-center gap-1",
                          request.status === 'pending' ? "bg-amber-100 text-amber-700" :
                          request.status === 'approved' ? "bg-emerald-100 text-emerald-700" :
                          request.status === 'completed' ? "bg-blue-100 text-blue-700" :
                          "bg-red-100 text-red-700"
                        )}>
                          {request.status === 'approved' && <Check size={12} />}
                          {request.status === 'completed' && <CheckCircle size={12} />}
                          {request.status === 'rejected' && <X size={12} />}
                          {request.status === 'pending' && <Clock size={12} />}
                          {request.status}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{request.remarks}</p>
                      <p className="text-xs text-gray-500 mt-1">Duration: {request.duration}</p>
                    </div>
                    <div className="text-xs text-gray-400 shrink-0">
                      Submitted on {format(request.timestamp, 'MMM dd, yyyy')}
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="mt-6 p-4 bg-violet-50 rounded-xl border border-violet-100">
              <p className="text-sm text-violet-700">
                <strong>Note:</strong> Student leave will be reviewed and approved by your allocated mentor staff.
              </p>
            </div>
          </div>
        </motion.div>
      )}
      </AnimatePresence>

      {/* Apply Leave Modal */}
      <AnimatePresence>
        {showLeaveModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-xl w-full max-w-md flex flex-col overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-violet-50 shrink-0">
                <h2 className="text-xl font-bold text-violet-950">Apply for Leave</h2>
                <button onClick={() => setShowLeaveModal(false)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-white rounded-full transition-colors">
                  <X size={24} />
                </button>
              </div>
              <form onSubmit={handleLeaveSubmit} className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Leave Type</label>
                  <select 
                    required 
                    value={leaveType} 
                    onChange={e => setLeaveType(e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-600 outline-none bg-white"
                  >
                    <option value="Sick Leave">Sick Leave</option>
                    <option value="Casual Leave">Casual Leave</option>
                    <option value="OD (On Duty)">OD (On Duty)</option>
                    <option value="Personal Work">Personal Work</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                    <input 
                      required 
                      type="datetime-local" 
                      value={fromDate} 
                      onChange={e => setFromDate(e.target.value)}
                      className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-600 outline-none" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                    <input 
                      required 
                      type="datetime-local" 
                      value={toDate} 
                      onChange={e => setToDate(e.target.value)}
                      className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-600 outline-none" 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Duration (e.g., 2 days)</label>
                  <input 
                    required 
                    type="text" 
                    value={duration} 
                    onChange={e => setDuration(e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-600 outline-none" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Remarks / Reason</label>
                  <textarea 
                    required 
                    value={remarks} 
                    onChange={e => setRemarks(e.target.value)}
                    placeholder="Enter reason for leave..."
                    className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-violet-600 outline-none resize-none bg-gray-50" 
                    rows={3}
                  />
                </div>
                
                <div className="pt-2 flex gap-3">
                  <button 
                    type="button"
                    onClick={() => setShowLeaveModal(false)}
                    className="flex-1 py-3 px-4 bg-red-500 text-white rounded-xl font-semibold hover:bg-red-600 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 py-3 px-4 bg-violet-600 text-white rounded-xl font-semibold hover:bg-violet-700 transition-colors"
                  >
                    Submit Leave Request
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
